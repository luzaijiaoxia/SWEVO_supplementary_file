Genetic Algorithm with Heuristic Initialization and Repair Strategy (GAHIR)

Miao Guo
June 10, 2019
email: guomiao618@163.com

The files in this zip archive are MATLAB m-files.

==============================================
Note:
The MATLAB files can be used to reproduce the results in the paper. The MATLB R2016a is used when implementing our method.  The STSC_SWEC_com folder includes the all algorithms for the STSCF problem. The MTMC_SWEC_com folder  includes the all algorithms for the MTMCF problem. 

=================STSC_SWEC_com folder==============
STSC_SWEC_main.m:
It includes the all algorithms. It does common processing like outputting results.

casefinal-folder:
It includes the instances of the comparison experiment (GAHIR/BMBO/IGA-SA/RS).

GA_multi_mecha.m:
It includes all the process of the GAHIR.

dynaConstruct_delet.m/dynaConstruct_uncertainS.m/dynaConstructS.m:
They are the initialization methods of the GAHIR.

search_solution_repair.m/search_solution_repair_rule.m/search_solution_repair_rule_uncertain.m:
They are the constraint handling methods of the GAHIR.

search_object_func.m:
It is the method to compute the objective values of the population.

stochastic_search.m:
It is the RS algorithm which is one of the competitors.

IGA_SA.m:
It is the IGA-SA algorithm  which is one of the competitors.

BMBO.m:
It is the BMBO algorithm  which is one of the competitors.

cplex.m:
It is achieved based on CPLEX12.5 (MATLAB version). Before running it, CPLEX needs to be installed.

=================MTMC_SWEC_com folder==============
MTMC_SWEC_main.m:
It includes the all algorithms. It does common processing like outputting results.

case_final-folder:
It includes the instances of the comparison experiment (GAHIR and RS).

MTMC_large_instance
It includes the large-scale instances of the comparison experiment (GAHIR and CPLEX).

GA_multi_mecha.m:
It includes all the process of the GAHIR.

MdynaConstruct_delet.m/MdynaConstruct_uncertainS.m/MdynaConstructS.m:
They are the initialization methods of the GAHIR.

Msearch_solution_repair.m/Msearch_solution_repair_rule.m/Msearch_solution_repair_rule_uncertain.m:
They are the constraint handling methods of the GAHIR.

Msearch_object_func.m:
It is the method to compute the objective values of the population.

delete_redundant.m:
It is the deletion strategy.

MRandomSearch.m
It is the RS algorithm which is one of the competitors.

Mcplex.m:
It is achieved based on CPLEX12.5 (MATLAB version). Before running it, CPLEX needs to be installed.



