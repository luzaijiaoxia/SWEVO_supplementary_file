function [Pop] = MdynaConstruct_delet(Task,Agent,agentCost)
%decremental heuristic initialization
agent_num = size(Agent,1);
ability_num = size(Task,2);
task_num = size(Task,1);

for i=1:2*agent_num
    aaa= rand(agent_num,1)>0.5;
    bbb= find(aaa==1);
    S=zeros(agent_num,task_num);
    hhh= randi(task_num,length(bbb),1);
    S(sub2ind(size(S),bbb,hhh))=1;
    Pop(:,:,i)=S;
end    
pop_size = size(Pop,3);
for i=1:pop_size
    aa = Pop(:,:,i)'*Agent;
    RTB = Task-aa;
    RTB =(RTB>0).*RTB; 
    ww = sum(RTB,2)==0;
    qq = find(ww==1);%delet superfluous agents
    for x=1:length(qq)
        while 1
            aa = Pop(:,:,i)'*Agent;
            duo = aa(qq(x),:)-Task(qq(x),:);
            ppp = find(Pop(:,qq(x),i)==1);
            A= Agent(ppp,:);
            uu = repmat(duo,size(A,1),1)-A;
            uuu = (uu<0);
            ccc = find(sum(uuu,2)==0);

            if isempty(ccc)
                break;
            else
                rn = randi(length(ccc));
                iii = ccc(rn);
                Pop(ppp(iii),qq(x),i)=0;
            end
        end
    end
end