function [Pop] = MdynaConstruct_uncertainS(Task,Agent,agentCost)
%%%incremental heuristic initializatio
agent_num = size(Agent,1);
ability_num = size(Task,2);
task_num = size(Task,1);
Pop=zeros(agent_num,task_num,2*agent_num);
    
pop_size = size(Pop,3);
for i=1:pop_size
    RAa = 1:agent_num;
    RT = 1:task_num;
    RTB=Task;
    RB = sum(Agent,1);
  
    while 1 %choose unassigned agents
        t_a = RTB./repmat(RB,size(RTB,1),1);
        t_a_ratio = t_a./repmat(sum(t_a,2),1,ability_num);
        t_a_z =[];
        for j=1:size(t_a,1)
            t_a_temp= repmat(t_a_ratio(j,:),length(RAa),1).*Agent(RAa,:);
            t_a_z(:,j) = sum(t_a_temp,2)./agentCost(RAa);
        end 
        if rand<0.5
            row = randi(length(RAa));
            col =randi(length(RT));
        else
            cc=max(max(t_a_z));
            [row,col]=find(t_a_z==cc,1);
        end
        Pop(RAa(row),RT(col),i) = 1;

        RTB(col,:) = RTB(col,:)-Agent(RAa(row),:);
        RTB(col,:) =(RTB(col,:)>0).*RTB(col,:);     
        RB = RB-Agent(RAa(row),:);
        if sum(RTB(col,:),2)==0
           RTB(col,:)=[]; RT(col)=[];
        end
        RAa(row)=[];
        if isempty(RAa)||isempty(RT)
            break;
        end
    end

end
end

