function mm_cplex_gai()
clc;clear
testcase=[1:15];
for testNum = 1:2
    fprintf('=================%d -th instance=================\n',testNum);
    run=20;
    for j=1:run
%     eval(['load case_final\case',num2str(testcase(testNum))]);

    eval(['load case_final\case',num2str(testNum)]);
    agent_num = size(Agent,1);
    ability_num = size(Task,2);
    task_num = size(Task,1);
    
    % Define variables
    x = binvar(task_num,agent_num,'full');
    % Define constraints 
    
    Constraints = [];
    for t=1:task_num
        absum=0;
        xx = repmat(x(t,:)',1,ability_num);
        absum = sum(Agent.*xx);
        Constraints = [Constraints, absum>=Task(t,:)];
    end 
    
    csum = sum(x,1);cone = ones(1,agent_num);
    Constraints = [Constraints,csum<=cone];

    % Define an objective  
    Objective = sum(sum(repmat(agentCost,1,task_num).*x'));
    % Set some options for YALMIP and solver
    options = sdpsettings('solver','cplex');
%     options.cplex.exportmodel ='model.lp';
    % Solve the problem
    sol = optimize(Constraints,Objective,options);
    mm_cplex_time(testNum,j) = sol.yalmiptime+sol.solvertime;
    datetime('now')
    % Analyze error flags
    if sol.problem == 0
        % Extract and display value
        solution = value(x);
        cost(testNum) = value(Objective);
    else
        display('Hmm, something went wrong!');
        sol.info
        yalmiperror(sol.problem)
    end
    
    feasible(testNum) =1;
     for t=1:task_num
        check=0;
        ss = repmat(solution(t,:)',1,ability_num);
        check = sum(Agent.*ss);
        zz = sum(check>=Task(t,:));
        if zz~=ability_num
            feasible(testNum)=0;break
        end
     end 
    cost_check(testNum) = sum(sum(repmat(agentCost,1,task_num).*solution'))==cost(testNum);
    end
    mm_cplex_timeAve = sum(mm_cplex_time,2)/run;
    save('MTMC_cplex11', 'mm_cplex_timeAve', 'mm_cplex_time','cost','feasible','cost_check');
    fprintf('----------------cost:%d---------------\n',cost(testNum));

    fprintf('---------------------------------------------------------------------\n');
end