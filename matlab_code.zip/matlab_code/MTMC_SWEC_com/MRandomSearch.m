function [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = MRandomSearch(Task,Agent,agentCost,Gmax,Np,p_z)
% RS
agent_num = size(Agent,1);
ability_num = size(Task,2);
task_num = size(Task,1);
global cost_gen;
cost_gen=0;
gen = 1;t=1;
Pc = 0.9;
Pm = 0.01;
restartCount = 0;record_plot=0;


while cost_gen<=Gmax*(Np)
    for i=1:Np
        aaa= rand(agent_num,1)>0.5;
        bbb= find(aaa==1);
        S=zeros(agent_num,task_num);
        hhh= randi(task_num,length(bbb),1);
        S(sub2ind(size(S),bbb,hhh))=1;
        Pop(:,:,i)=S;
    end    
    [PopCost,PopDone] = Msearch_object_func(Pop,Task,Agent,agentCost);     

    %---------record data---------------%  
    [genCost(gen),ls_index] = min(PopCost);
    genS(:,:,gen) = Pop(:,:,ls_index);    
    if gen==1
        bestCost(gen) = genCost(gen);
    else
        temp = bestCost(gen-1)<genCost(gen);
        bestCost(gen) = bestCost(gen-1).*temp + genCost(gen).*(~temp);
    end
    
    %plot data
    genflag = floor(cost_gen/(p_z));
    if genflag==1&&t==1
        record_plot(t:genflag) = bestCost(gen);
        t=t+1;
    elseif genflag>=t
        record_plot(t:genflag) = bestCost(gen);
        t = genflag+1;    
    end 
       
    gen = gen+1;
end

record_plot = [bestCost(1) record_plot];

[gbestCost,g_index] = min(genCost);
gbestS = genS(:,:,g_index);
B_gbestS = gbestS'*Agent;
temp1 = sum(B_gbestS>=Task,2);
taskPerform = sum((temp1==ability_num))==task_num;

end
