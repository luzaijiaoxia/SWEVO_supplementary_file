function [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = MGA_multi_mecha(Task,Agent,agentCost,Gmax,Np,p_z,initType,constraintDealType,LsType)
% GAHIR
agent_num = size(Agent,1);
ability_num = size(Task,2);
task_num = size(Task,1);
global cost_gen;
cost_gen=0;
gen = 1;t=1;
Pc = 0.9;
Pm = 0.01;
restartCount = 0;record_plot=0;
%��ʼ����Ⱥ
%initialize the population
switch initType
    case 1  %�����ʼ���� %%random initialization
        for i=1:Np
            aaa= rand(agent_num,1)>0.5;
            bbb= find(aaa==1);
            S=zeros(agent_num,task_num);
            hhh= randi(task_num,length(bbb),1);
            S(sub2ind(size(S),bbb,hhh))=1;
            Pop(:,:,i)=S;
        end
    case 2  %1/3���в�ȷ���Ĺ����ʼ���⣬�ӹ���%incremental heuristic initialization
        [S] = MdynaConstruct_uncertainS(Task,Agent,agentCost);
        Pop=S;
        for i=size(S,3)+1:Np
            aaa= rand(agent_num,1)>0.5;
            bbb= find(aaa==1);
            S=zeros(agent_num,task_num);
            hhh= randi(task_num,length(bbb),1);
            S(sub2ind(size(S),bbb,hhh))=1;
            Pop(:,:,i)=S;
        end
    case 3  %1/3���в�ȷ���Ĺ����ʼ���⣬ɾ����%decremental heuristic initialization
        [S] = MdynaConstruct_delet(Task,Agent,agentCost);%ɾ����
        Pop=S;
        for i=size(S,3)+1:Np
            aaa= rand(agent_num,1)>0.5;
            bbb= find(aaa==1);
            S=zeros(agent_num,task_num);
            hhh= randi(task_num,length(bbb),1);
            S(sub2ind(size(S),bbb,hhh))=1;
            Pop(:,:,i)=S;
        end        
    case 4  %����һ���Ϻý�+���%%hybrid generation based initialization 
        [Pop] = MdynaConstructS(Task,Agent,agentCost);
        for i=2:Np
            aaa= rand(agent_num,1)>0.5;
            bbb= find(aaa==1);
            S=zeros(agent_num,task_num);
            hhh= randi(task_num,length(bbb),1);
            S(sub2ind(size(S),bbb,hhh))=1;
            Pop(:,:,i)=S;
        end

end
%Ŀ�꺯��ֵ����&���޸�
%repair solutions & compute objective values
switch constraintDealType
    case 2  %����޸� %%Random repair strategy
        [Pop] = Msearch_solution_repair(Pop,Task,Agent,agentCost);
    case 3 %�������޸�+��� %%Hybrid repair strategy 
        [Pop] = Msearch_solution_repair_rule_uncertain(Pop,Task,Agent,agentCost);
    case 4  %�������޸� %%Heuristic repair strategy
        [Pop] = Msearch_solution_repair_rule(Pop,Task,Agent,agentCost);
end
%The penalty function method & compute objective values of the population
[PopCost,PopDone] = Msearch_object_func(Pop,Task,Agent,agentCost); 

while cost_gen<=Gmax*(Np)
    for og = 1:2:Np
  %-----------------------selection-------------% 
       s1 = GA_selection(Pop,PopCost,Np);
       s2 = GA_selection(Pop,PopCost,Np);
  %--------------------crossover------------------%
       if rand<Pc
           s = GA_crossover(s1,s2,agent_num);
       else
           s =cat(3,s1,s2);
       end
  %-------------------mutation--------------------%  
       randmtemp = rand(agent_num,2)<Pm;
       for i=1:2            %��1��λ��
           rindt = find(randmtemp(:,i)==1);
           if ~isempty(rindt)
           s(rindt,:,i)=0;
           radit = randi(task_num,length(rindt),1);
           s(sub2ind(size(s),rindt,radit,repmat(i,length(rindt),1)))=1;
%            else
%                Os(:,:,og-1+i) = s(:,:,i);
           end
       end
       randmtemp = rand(agent_num,2)<Pm;
       for i=1:2            %1->0
           rindt = find(randmtemp(:,i)==1);
           if ~isempty(rindt)
           s(rindt,:,i)=0;
%            else
%                Os(:,:,og-1+i) = s(:,:,i);
           end
       end
       Os(:,:,og-1+1) = s(:,:,1);
       Os(:,:,og-1+2) = s(:,:,2);
    end
  
    [Os]=delete_redundant(Os,Task,Agent,agentCost);%deletion strategy
    
    %Ŀ�꺯��ֵ����&���޸�
    %compute objective values of the population & repair solutions
    switch constraintDealType
        case 2  %����޸� %%Random repair strategy
            [Os] = Msearch_solution_repair(Os,Task,Agent,agentCost);
        case 3 %�������޸�+��� %%Hybrid repair strategy 
            [Os] = Msearch_solution_repair_rule_uncertain(Os,Task,Agent,agentCost);
        case 4  %�������޸� %%Heuristic repair strategy
            [Os] = Msearch_solution_repair_rule(Os,Task,Agent,agentCost);
    end
    %The penalty function method & compute objective values of the population
    [OsCost,OsDone] = Msearch_object_func(Os,Task,Agent,agentCost); 
    
    %-------------population update--------------%
    PopSum = cat(3,Pop,Os);
    PopSumCost = [PopCost;OsCost];
    PopSumDone = [PopDone;OsDone];
    [~,gen_index] = sort(PopSumCost);
    
        
    PopCostStd = std(PopCost,1);
    
    Pop = PopSum(:,:,gen_index(1:Np));
    PopCost = PopSumCost(gen_index(1:Np));
    PopDone = PopSumDone(gen_index(1:Np));
    
%     dindex=1:Np;%find(PopDone==1);
%     PopCostMean = mean(PopCost(dindex));
%     PopMax = max(PopCost(dindex));
%     if isempty(dindex)
%         upk(gen)=1;
%     else
%         upk(gen)=(PopMax-PopCostMean)/PopMax;
%     end
%     SubNp(gen) = round(Np/2)+round(upk(gen)*Np);
%     SubNp(gen)=Np;%(SubNp(gen)>Np)*Np+~(SubNp(gen)>Np)*SubNp(gen);%Np;
%     
% %     PopCostStd(gen) = std(PopCost,1);
%     PopCostStd = std(PopCost,1);
% 
%     Pop = PopSum(:,:,gen_index(1:SubNp(gen)));
%     PopCost = PopSumCost(gen_index(1:SubNp(gen)));
%     PopDone = PopSumDone(gen_index(1:SubNp(gen)));
%     
%     upindex = SubNp(gen)+randperm(size(PopSumCost,1)-SubNp(gen),Np-SubNp(gen));%���
%     Pop(:,:,SubNp(gen)+1:Np) = PopSum(:,:,upindex);
%     PopCost(SubNp(gen)+1:Np) = PopSumCost(upindex);
%     PopDone(SubNp(gen)+1:Np) = PopSumDone(upindex);

    %---------��¼ÿ�����---------------%  
    %record data
    %%record,genCost is the best in each generation
    %%bestCost is the best up to now.
    [genCost(gen),ls_index] = min(PopCost);
    genS(:,:,gen) = Pop(:,:,ls_index);    
    if gen==1
        bestCost(gen) = genCost(gen);
    else
        temp = bestCost(gen-1)<genCost(gen);
        bestCost(gen) = bestCost(gen-1).*temp + genCost(gen).*(~temp);
    end
    
    %plot data
    genflag = floor(cost_gen/(p_z));
    if genflag==1&&t==1
        record_plot(t:genflag) = bestCost(gen);
        t=t+1;
    elseif genflag>=t
        record_plot(t:genflag) = bestCost(gen);
        t = genflag+1;%t+1;    
    end 
    
    %---------------������ /restart---------------%
   
    if PopCostStd<1
        restartCount = restartCount +1;
        %��ʼ����Ⱥ
        %initialize the population
        switch initType
            case 1  %�����ʼ���� %%random initialization
                for i=1:Np
                    aaa= rand(agent_num,1)>0.5;
                    bbb= find(aaa==1);
                    S=zeros(agent_num,task_num);
                    hhh= randi(task_num,length(bbb),1);
                    S(sub2ind(size(S),bbb,hhh))=1;
                    Pop(:,:,i)=S;
                end
            case 2  %1/3���в�ȷ���Ĺ����ʼ���⣬�ӹ���%incremental heuristic initialization
                [S] = MdynaConstruct_uncertainS(Task,Agent,agentCost);
                Pop=S;
                for i=size(S,3)+1:Np
                    aaa= rand(agent_num,1)>0.5;
                    bbb= find(aaa==1);
                    S=zeros(agent_num,task_num);
                    hhh= randi(task_num,length(bbb),1);
                    S(sub2ind(size(S),bbb,hhh))=1;
                    Pop(:,:,i)=S;
                end
            case 3  %1/3���в�ȷ���Ĺ����ʼ���⣬ɾ����%decremental heuristic initialization
                [S] = MdynaConstruct_delet(Task,Agent,agentCost);%ɾ����
                Pop=S;
                for i=size(S,3)+1:Np
                    aaa= rand(agent_num,1)>0.5;
                    bbb= find(aaa==1);
                    S=zeros(agent_num,task_num);
                    hhh= randi(task_num,length(bbb),1);
                    S(sub2ind(size(S),bbb,hhh))=1;
                    Pop(:,:,i)=S;
                end        
            case 4  %����һ���Ϻý�+���%%hybrid generation based initialization 
                [Pop] = MdynaConstructS(Task,Agent,agentCost);
                for i=2:Np
                    aaa= rand(agent_num,1)>0.5;
                    bbb= find(aaa==1);
                    S=zeros(agent_num,task_num);
                    hhh= randi(task_num,length(bbb),1);
                    S(sub2ind(size(S),bbb,hhh))=1;
                    Pop(:,:,i)=S;
                end

        end
        %Ŀ�꺯��ֵ����&���޸�
        %repair solutions & compute objective values
        switch constraintDealType
            case 2  %����޸� %%Random repair strategy
                [Pop] = Msearch_solution_repair(Pop,Task,Agent,agentCost);
            case 3 %�������޸�+��� %%Hybrid repair strategy 
                [Pop] = Msearch_solution_repair_rule_uncertain(Pop,Task,Agent,agentCost);
            case 4  %�������޸� %%Heuristic repair strategy
                [Pop] = Msearch_solution_repair_rule(Pop,Task,Agent,agentCost);
        end
        %The penalty function method & compute objective values of the population
        [PopCost,PopDone] = Msearch_object_func(Pop,Task,Agent,agentCost); 

    end
    
    gen = gen+1;
end

record_plot = [bestCost(1) record_plot];

[gbestCost,g_index] = min(genCost);
gbestS = genS(:,:,g_index);
B_gbestS = gbestS'*Agent;
temp1 = sum(B_gbestS>=Task,2);
taskPerform = sum((temp1==ability_num))==task_num;

end

%------------------------selection-----------------------------%
function s = GA_selection(Pop,PopCost,Np)
    temp = randperm(Np,2);
    [~,index] = min(PopCost(temp));
    ind = temp(index);
    s = Pop(:,:,ind);   
end
%------------------------crossover-----------------------------%
function s = GA_crossover(s1,s2,agent_num)  
    r = rand(agent_num,1);
    r_temp = r>0.5;
    s(:,:,1) = s1.*repmat(r_temp,1,size(s1,2)) + s2.*~(repmat(r_temp,1,size(s1,2)));
    s(:,:,2) = s2.*repmat(r_temp,1,size(s1,2)) + s1.*~(repmat(r_temp,1,size(s1,2))); 
    
end

