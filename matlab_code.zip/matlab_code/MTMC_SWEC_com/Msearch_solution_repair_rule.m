function [Pop] = Msearch_solution_repair_rule(Pop,Task,Agent,agentCost)
%Heuristic repair strategy
task_num = size(Task,1);
ability_num = size(Task,2);
ability_num = size(Task,2);

pop_size = size(Pop,3);
for i=1:pop_size
%     if rand<0.5   
   
    aa = Pop(:,:,i)'*Agent;
    RTB = Task-aa;
    RTB =(RTB>0).*RTB;  
    
    RA = ~sum(Pop(:,:,i),2);%unassigned agents
    RAa = find(RA==1);
    bb =sum(RTB,2)>0;
    RT = find(bb==1);
    if isempty(RAa)||isempty(RT)
        continue;
    end
    
    RTB =RTB(RT,:);
    RB = RA'*Agent;
%     t_a = RTB./RB;
%     t_a_ratio = t_a./sum(t_a,2);
%     t_a_z =[];
%     for j=1:size(t_a,1)
%         t_a_temp= t_a_ratio(j,:).*Agent(RAa,:);
%         t_a_z(:,j) = sum(t_a_temp,2)./agentCost(RAa);
%     end
    while 1
        t_a = RTB./repmat(RB,size(RTB,1),1);
        t_a_ratio = t_a./repmat(sum(t_a,2),1,ability_num);
        t_a_z =[];
        for j=1:size(t_a,1)
            t_a_temp= repmat(t_a_ratio(j,:),length(RAa),1).*Agent(RAa,:);
            t_a_z(:,j) = sum(t_a_temp,2)./agentCost(RAa);
        end 
%         if rand<0.5
%             row = randi(length(RAa));
%             col =randi(length(RT));
%         else
            cc=max(max(t_a_z));
            [row,col]=find(t_a_z==cc,1);
%         end
        Pop(RAa(row),RT(col),i) = 1;

        RTB(col,:) = RTB(col,:)-Agent(RAa(row),:);
        RTB(col,:) =(RTB(col,:)>0).*RTB(col,:);     
        RB = RB-Agent(RAa(row),:);
        if sum(RTB(col,:),2)==0
           RTB(col,:)=[]; RT(col)=[];
        end
        RAa(row)=[];
        if isempty(RAa)||isempty(RT)
            break;
        end
    end
 
end
end