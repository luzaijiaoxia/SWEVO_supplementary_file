function testcase
clear;
% Agent = randi(200,50,3);
% 
% Task(1,:) = randi(round(max(sum(Agent))*0.25),1,3);
% Task(2,:) = randi(round(max(sum(Agent))*0.25),1,3);
% Task(3,:) = randi(round(max(sum(Agent))*0.25),1,3);
% agentCost = randi(200,50,1);
% N = [5];%[10 30 50 70 100];%����������
% NM = [2];%���������������[2 4];%
% K = [3];%����ά��
% cc = 1;
% for k = 1:size(K,2)
% for i = 1:size(N,2)
%     j =1;
%     while j <=size(NM,2)
%         M = floor(N(i)/NM(j));%��������
%         Task=[];Agent=[];agentCost=[];
%         Task = randi(200,M,K(k));
%         Agent = [];
%         for t=1:K(k)
%                 temp = ceil(sum(Task(:,t))./N(j));
%                 aa = temp*1+randi(round(1.*temp),N(i),1);%1~1.5���
%                 Agent(:,t) = aa;
%                     
%         end
%         
%         agentCost = randi(200,N(i),1);
%         ccc = sprintf('%s%d','case',cc);
%         done = 0;
% %         [~,~,taskPerform] = mmhybridPSO(Task,Agent,agentCost,1000,5.*size(Agent,1));
%         [SCost,S_part1,S_part2,taskPerform] = mmConstruc_while(Task,Agent,agentCost);
% %         [GA_gPopCost,GA_genCost,gPop_part1,gPop_part2,GA_taskPerform] = mmGA(Task,Agent,agentCost,1000,5.*size(Agent,1));
%         if taskPerform==1
%             eval(['save ',ccc,' Task',' Agent',' agentCost']);
%             j = j+1;cc = cc+1;
%         end
%         
%     end
% end
% end
% 
% 
% N = [8];%[10 30 50 70 100];%����������
% NM = [2 4];%[5 2];%���������������
% K = [3];%����ά��
% % cc = 1;
% for k = 1:size(K,2)
% for i = 1:size(N,2)
%     j =1;
%     while j <=size(NM,2)
%         M = N(i)/NM(j);%��������
%         Task=[];Agent=[];agentCost=[];
%         for m = 1:M
%             Task(m,:) = randi(200,1,K(k));
%             for t=1:K(k)
%                 temp = ceil(Task(m,t)./NM(j));
%                     aa = temp*1+randi(round(1.*temp),NM(j),1);%1~1.5���
%                     if m==1
%                         Agent(1:NM(j),t) = aa;
%                     else
%                         Agent((m-1)*NM(j)+1:m*NM(j),t) = aa;
%                     end
%             end
%         end
%         agentCost = randi(200,N(i),1);
%         ccc = sprintf('%s%d','case',cc);
%         done = 0;
%         [SCost,S_part1,S_part2,done] = mmConstruc_while(Task,Agent,agentCost);
% %         [GA_gPopCost,GA_genCost,gPop_part1,gPop_part2,GA_taskPerform] = mmGA(Task,Agent,agentCost,1000,5.*size(Agent,1));
%         if done==1
%             eval(['save ',ccc,' Task',' Agent',' agentCost']);
%             j = j+1;cc = cc+1;
%         end
%         
%     end
% end
% end

N = [70 100];%����������
NM = [10 5 2];%���������������
K = [3];%����ά��
cc = 10;
for k = 1:size(K,2)
for i = 1:size(N,2)
    j =1;
    while j <=size(NM,2)
        M = N(i)/NM(j);%��������
        Task=[];Agent=[];agentCost=[];
        for m = 1:M
            Task(m,:) = randi(200,1,K(k));
            for t=1:K(k)
                temp = ceil(Task(m,t)./NM(j));
                    aa = temp*1+randi(round(1.*temp),NM(j),1);%1~1.5���
                    if m==1
                        Agent(1:NM(j),t) = aa;
                    else
                        Agent((m-1)*NM(j)+1:m*NM(j),t) = aa;
                    end
            end
        end
        agentCost = randi(200,N(i),1);
        ccc = sprintf('%s%d','case',cc);
%         done = 0;
%         [SCost,S_part1,S_part2,done] = mmConstruc_while(Task,Agent,agentCost);
%         [GA_gPopCost,GA_genCost,gPop_part1,gPop_part2,GA_taskPerform] = mmGA(Task,Agent,agentCost,1000,5.*size(Agent,1));
%         if done==1
            eval(['save ',ccc,' Task',' Agent',' agentCost']);
            j = j+1;cc = cc+1;
            if M==1
                cc=cc-1;
            end
%         end
        
    end
end
end

end