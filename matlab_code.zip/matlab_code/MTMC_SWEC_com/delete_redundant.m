function [Pop]=delete_redundant(Pop,Task,Agent,agentCost)
%deletion strategy
task_num = size(Task,1);
pop_size = size(Pop,3);
for i=1:pop_size
    aa = Pop(:,:,i)'*Agent;
    RTB = Task-aa;
    RTB =(RTB>0).*RTB; 
    ww = sum(RTB,2)==0;
    qq = find(ww==1);
    for x=1:length(qq)
        while 1
            aa = Pop(:,qq(x),i)'*Agent;
            duo = aa-Task(qq(x),:);
            ppp = find(Pop(:,qq(x),i)==1);
            A= Agent(ppp,:);
            uu = repmat(duo,size(A,1),1)-A;
            uuu = (uu<0);
            iii = find(sum(uuu,2)==0);
                        
            if isempty(iii)
                break;
            elseif length(iii)==1
                Pop(ppp(iii),qq(x),i)=0;
            else
                qqq = agentCost(ppp(iii));
                ind = randi(length(qqq));
                Pop(ppp(iii(ind)),qq(x),i)=0;
            end
        end
    end
end