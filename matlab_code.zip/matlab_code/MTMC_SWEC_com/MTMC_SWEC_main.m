function MTMC_SWEC_main()
% Gmax;            %���������� /maximum iteration number
% Np;              %��Ⱥ��ģ /population size
% ����������������������agent���������ʹ���
% Task(i,j)��ʾ����i�ĵ�j����������ֵ /task requirement
% Agent(i,j)��ʾ��i��agent��ӵ�е�j�������Ĵ�С /agent ability
% agentCost(i)��ʾ��i��agent�������˵Ĵ��� /agent cost

clear;close;
tic;
for testNum = 1:2%instance
    %A = load(['MTMC_large_instance\case',num2str(testNum)]);
    A = load(['case_final\case',num2str(testNum)]);
    
    Task = A.Task;
    Agent = A.Agent;
    agentCost = A.agentCost;
    Gmax = 3000;
    Np = 6*size(Agent,1);
    run =20;%run times
    fprintf('=================the %d-th instance=================\n',testNum);   
    p_z=round(Gmax*(Np)/100);
    
% % % %--------------------RS--------------------------------%
fprintf('----------------RS---------------\n');
    RS_record_p = [];
    to = clock;    
    for j=1:run
        [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = MRandomSearch(Task,Agent,agentCost,Gmax,Np,p_z);
        gg_index(testNum,j) = g_index;
        RS_cost(testNum,j) = gbestCost;
        %restaCount(testNum,j) = restartCount;
        RS_Perform(testNum,j) = taskPerform;
        if j>1
            a=length(record_plot);
            b=size(RS_record_p,2);
            if a<b
                record_plot=[record_plot record_plot(end).*ones(1,b-a)];
            else
                record_plot(b+1:a)=[];
            end
        end
        RS_record_p(j,:) = record_plot;
    end
    RS_time(testNum) = etime(clock,to)/run;
    
    RS_record_p_Ave = mean(RS_record_p,1);
    px = p_z*(1:size(RS_record_p_Ave,2)-1);
    px=[1 px];
%     eval(['save figure','\RS_case',num2str(testNum),' px',' RS_record_p_Ave']);
%     plot(px,RS_record_p_Ave,'-.');hold on;    
%     fprintf('%d\n',mean(ls_cost))
%     fprintf('�������ܴ���%d',sum(restaCount(testNum,:),2));
    
    RS_costBest(testNum,1) = min(RS_cost(testNum,:));
    RS_costAve(testNum,1) = mean(RS_cost(testNum,:));
    RS_costMid(testNum,1) = median(RS_cost(testNum,:));
    RS_costStd(testNum,1) = std(RS_cost(testNum,:));
    RS_mPerform(testNum,1) = mean(RS_Perform(testNum,:));
    fprintf('����㷨��ý�� /best result��%d\n',RS_costBest(testNum,1));
    fprintf('����㷨ƽ����� /mean result��%d\n',RS_costAve(testNum,1));
    fprintf('����㷨��λ����� /median result��%d\n',RS_costMid(testNum,1));
    fprintf('����㷨��׼���� /standard deviation��%d\n',RS_costStd(testNum,1));
%     fprintf('���������ɣ�%d\n',RS_mPerform(testNum,1));
    fprintf('�������ʱ�� /time(s): %d\n',RS_time(testNum));    
    save dataRS RS_cost RS_costAve RS_costStd RS_time;
%     


% % % ----------------------------GAHIR-------------------------%

    para=[3 4 0];%different combinations of initialization methods and constraint handling strategies
%     para=[1 1 0;1 2 0;1 3 0; 1 4 0;
%         2 1 0;2 2 0;2 3 0; 2 4 0;
%         3 1 0;3 2 0;3 3 0; 3 4 0;
%         4 1 0;4 2 0;4 3 0; 4 4 0];

    figure_data_temp_x = cell(size(para,1),1);
    figure_data_temp_y = cell(size(para,1),1);
    GA_cost_temp = zeros(run,size(para,1));
    for type=1:size(para,1)
        
        fprintf('----------------the %d-th GAHIR---------------\n',type);         
        GA_record_p = [];k=1;
        to = clock; 
        for r=1:run
            [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = MGA_multi_mecha(Task,Agent,agentCost,Gmax,Np,p_z,para(type,1),para(type,2),para(type,3));
%             GA_gg_index(testNum,r,type) = g_index;
            GA_cost_temp(r,type) = gbestCost;
%             restaCount(testNum,r,type) = restartCount;%����������
%             GA_Perform(testNum,r,type) = taskPerform;%�Ƿ�����������
            if r>1
                a=length(record_plot);
                b=size(GA_record_p,2);
                if a<b
                    record_plot=[record_plot record_plot(end).*ones(1,b-a)];
                else
                    record_plot(b+1:a)=[];
                end
            end                
            GA_record_p(r,:) = record_plot;
        end
        GA_time_temp(1,type) = etime(clock,to)/run;
        %��ͼ
        GA_record_p_Ave = mean(GA_record_p,1);
        px = p_z*(1:size(GA_record_p_Ave,2)-1);
        px=[1 px];
        figure_data_temp_x{type,1}=px;
        figure_data_temp_y{type,1}=GA_record_p_Ave;
        
%         eval(['save figure','\GA340_case',num2str(testNum),'_type',num2str(type),' px',' GA_record_p_Ave']);
%         plotlength = round(length(px)/6);
%         plot(px,GA_record_p_Ave,'-','LineWidth',1.4);hold on;       
    end
    GA_cost(testNum,:,:) = GA_cost_temp;
    GA_figure_data{:,1,testNum} = figure_data_temp_x;
    GA_figure_data{:,2,testNum} = figure_data_temp_y;
    GA_time(testNum,:) = GA_time_temp;
    for type=1:size(para,1)
%         fprintf('----------------%d---------------\n',type);  
        GA_costBest(testNum,type) = min(GA_cost(testNum,:,type));
        GA_costAve(testNum,type) = mean(GA_cost(testNum,:,type));
        GA_costMid(testNum,type) = median(GA_cost(testNum,:,type));
        GA_costStd(testNum,type) = std(GA_cost(testNum,:,type));
%         GA_mPerform(testNum,type) = mean(GA_Perform(testNum,:,type));
    %     fprintf('��%d�����\n',k);
        fprintf('GA�㷨��ý�� /best result��%d\n',GA_costBest(testNum,type));
        fprintf('GA�㷨ƽ����� /mean result��%d\n',GA_costAve(testNum,type));
        fprintf('GA�㷨��λ����� /median result��%d\n',GA_costMid(testNum,type));
        fprintf('GA�㷨��׼���� /standard deviation��%d\n',GA_costStd(testNum,type));
%         fprintf('GA������ɣ�%d\n',GA_mPerform(testNum,type));
        fprintf('GA����ʱ�� /time(s): %d\n',GA_time(testNum,type));
    end
    
    save dataGAtime_ninety GA_cost GA_costAve GA_costStd GA_time GA_figure_data;

end
toc;