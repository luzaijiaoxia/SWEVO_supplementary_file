function [PopCost,done] = Msearch_object_func(Pop,Task,Agent,agentCost)
%objective value
%0-1 encoding matrix
global cost_gen;
task_num = size(Task,1);
pop_size = size(Pop,3);
cost_gen = cost_gen+pop_size;
costSum = sum(agentCost);

taskDone = zeros(1,task_num);
cost = zeros(1,task_num);
PopCost = zeros(pop_size,1);
done =  zeros(pop_size,1);
for p = 1:pop_size
for i =1:task_num
        a_order = Pop(:,i,p);
        a_sum = a_order'*Agent;
        taskDone(i) = all(a_sum>=Task(i,:));
        if taskDone(i)~=0
            cost(i) = a_order'*agentCost;
        else
            a_cha = ((Task(i,:)-a_sum)>0).*(Task(i,:)-a_sum);
            cost(i) = sum(a_cha./Task(i,:))/3;
        end
        
end

if ~isempty(find(taskDone==0, 1))%��δ��ɵ����񣬷����� %infeasible penalty function
    done(p) = 0;
    PopCost(p) = costSum.*(1+sum((~taskDone).*cost));
else%feasible
    PopCost(p) = sum(cost);
    done(p) = 1;
end
end
end