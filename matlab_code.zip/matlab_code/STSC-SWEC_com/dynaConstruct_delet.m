function [S] = dynaConstruct_delet(Task,Agent,agentCost)
%decremental heuristic initialization
agent_num = size(Agent,1);
ability_num = size(Task,2);%
agentcost = agentCost;
S = rand(agent_num,agent_num)>0.5;%random initialization
pop_size = size(S,1);
for i=1:pop_size
    aa = S(i,:)*Agent;
    RTB = Task-aa;
    RTB =(RTB>0).*RTB; 
    ww = sum(RTB,2)==0;
    if ww==1%delet superfluous agents
        while 1 
            aa = S(i,:)*Agent;
            duo = aa - Task;
            ppp = find(S(i,:)==1);
            A = Agent(ppp,:);
            uu = repmat(duo,size(A,1),1)-A;
            uuu = (uu<0);
            ccc = find(sum(uuu,2)==0);
            if isempty(ccc)
                break;
            else
                rn = randi(length(ccc));
                iii = ccc(rn);
                S(i,ppp(iii))=0;
            end
        end
        
    end
end