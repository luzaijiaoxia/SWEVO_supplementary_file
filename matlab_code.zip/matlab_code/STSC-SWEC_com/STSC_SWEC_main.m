function STSC_SWEC_main()
% Gmax;            %maximum  iteration number
% Np;              %the population size
% ����������������������agent���������ʹ���
% Task(i,j)��ʾ����i�ĵ�j����������ֵ /task requirement
% Agent(i,j)��ʾ��i��agent��ӵ�е�j�������Ĵ�С /agent ability
% agentCost(i)��ʾ��i��agent�������˵Ĵ��� /agent cost
%para :initType,constraintDealType,LsType
clear;close;
tic;%�����ʱ
for testNum = 1:2
    A = load(['casefinal\case',num2str(testNum)]);%test cases
    Task = A.Task;
    Agent = A.Agent;
    agentCost = A.agentCost;
    
    Gmax = 1000;%200;
    Np = 2*size(Agent,1);
    run =20;%���д��� /run times
    fprintf('=================the %d-th instance=================\n',testNum);   
    p_z=round(Gmax*(Np)/100);%100;interval of plot figure
    
% %--------------------stochastic--------------------------------%
fprintf('----------------RS---------------\n');
    stochastic_record_p = [];
    to = clock;    
    for j=1:run
        [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = stochastic_search(Task,Agent,agentCost,Gmax,Np,p_z);
        gg_index(testNum,j) = g_index;
        stochastic_cost(testNum,j) = gbestCost;
        restaCount(testNum,j) = restartCount;
        stochastic_Perform(testNum,j) = taskPerform;
        if j>1
            a=length(record_plot);
            b=size(stochastic_record_p,2);
            if a<b
                record_plot=[record_plot record_plot(end).*ones(1,b-a)];
            else
                record_plot(b+1:a)=[];
            end
        end                
        stochastic_record_p(j,:) = record_plot;
    end
    stochastic_time(testNum) = etime(clock,to)/run;
    
    stochastic_record_p_Ave = mean(stochastic_record_p,1);
    px = p_z*(1:size(stochastic_record_p_Ave,2)-1);
    px=[1 px];
    %eval(['save figure','\RS_case',num2str(testNum),' px',' stochastic_record_p_Ave']);
%     plot(px,stochastic_record_p_Ave,'-.');hold on;    
%     fprintf('%d\n',mean(ls_cost))
%     fprintf('�������ܴ���%d',sum(restaCount(testNum,:),2));
    
    stochastic_costBest(testNum,1) = min(stochastic_cost(testNum,:));
    stochastic_costAve(testNum,1) = mean(stochastic_cost(testNum,:));
    stochastic_costMid(testNum,1) = median(stochastic_cost(testNum,:));
    stochastic_costStd(testNum,1) = std(stochastic_cost(testNum,:));
    stochastic_mPerform(testNum,1) = mean(stochastic_Perform(testNum,:));
    fprintf('����㷨��ý��/best result��%d\n',stochastic_costBest(testNum,1));
    fprintf('����㷨ƽ�����/mean result��%d\n',stochastic_costAve(testNum,1));
    fprintf('����㷨��λ�����/median result��%d\n',stochastic_costMid(testNum,1));
    fprintf('����㷨��׼����/standard deviation��%d\n',stochastic_costStd(testNum,1));
%     fprintf('���������ɣ�%d\n',stochastic_mPerform(testNum,1));
    fprintf('�������ʱ��/time(s):%d\n',stochastic_time(testNum));    
    save dataRS stochastic_cost stochastic_costAve stochastic_costStd stochastic_time;

% % % %--------------------------BMBO------------------------%   
fprintf('---------------BMBO---------------\n');
    to = clock;
%     chushi = datestr(now)
    BMBOfiguretemp=cell(1,run);BMBO_record_p=[];
    for j=1:run 
        [gPopCost,genCost,taskPerform,BMBO_record_plot] = BMBO(Task,Agent,agentCost,Gmax,Np,p_z);
        %jieshu = datestr(now)
        BMBO_cost(testNum,j) = gPopCost;
        BMBO_Perform(testNum,j) = taskPerform;
        BMBOfiguretemp{1,j}=BMBO_record_plot;
    end
    for j=1:run
%         ft= BMAfigure{testNum,j};
        BMBO_record_plot=BMBOfiguretemp{1,j};
        if j>1
            a=length(BMBO_record_plot);
            b=size(BMBO_record_p,2);
            if a<b
                BMBO_record_plot=[BMBO_record_plot BMBO_record_plot(end).*ones(1,b-a)];
            else
                BMBO_record_plot(b+1:a)=[];
            end
        end    
        BMBO_record_p(j,:) = BMBO_record_plot;        
    end
    BMBO_record_p_Ave = mean(BMBO_record_p,1);
    px = p_z*(1:size(BMBO_record_p_Ave,2)-1);
    px=[1 px];
    BMBOfigure{testNum,1} = px;
    BMBOfigure{testNum,2} = BMBO_record_p_Ave; 
% %     plot(px,PSO_record_p_Ave,'--','LineWidth',1.4);hold on;
    %eval(['save figure','\BMBO_case',num2str(testNum),' px',' BMBO_record_p_Ave']);    
    
    BMBO_time(testNum,1) = etime(clock,to)/run;
    BMBO_costBest(testNum,1) = min(BMBO_cost(testNum,:));
    BMBO_costAve(testNum,1) = mean(BMBO_cost(testNum,:));
    BMBO_costMid(testNum,1) = median(BMBO_cost(testNum,:));
    BMBO_costStd(testNum,1) = std(BMBO_cost(testNum,:));
    BMBO_tPerform(testNum,1) = mean(BMBO_Perform(testNum,:));
    fprintf('BMBO�㷨ƽ�����/mean result��%d\n',BMBO_costAve(testNum));
    fprintf('BMBO�㷨��λ�����/median result��%d\n',BMBO_costMid(testNum));
    fprintf('BMBO�㷨��׼����/standard deviation��%d\n',BMBO_costStd(testNum));
%     fprintf('������ɣ�%d\n',BMBO_tPerform(testNum,1));
    fprintf('BMBO����ʱ��/time(s):%d\n',BMBO_time(testNum));
    
    save dataBMBO BMBO_cost BMBO_costAve BMBO_costStd BMBO_time BMBOfigure;

% % % %--------------------------IGA_SA------------------------%  
fprintf('----------------IGA-SA---------------\n');
    to = clock;
    chushi = datestr(now)
    IGA_SAfiguretemp=cell(1,run);IGA_SA_record_p=[];
    for j=1:run 
        [gPopCost,genCost,taskPerform,IGA_SA_record_plot] = IGA_SA(Task,Agent,agentCost,Gmax,Np,p_z);
        %jieshu = datestr(now)
        IGA_SA_cost(testNum,j) = gPopCost;
        IGA_SA_Perform(testNum,j) = taskPerform;%�Ƿ�����������
        IGA_SAfiguretemp{1,j}=IGA_SA_record_plot;
    end
    for j=1:run
%         ft= BMAfigure{testNum,j};
        IGA_SA_record_plot=IGA_SAfiguretemp{1,j};
        if j>1
            a=length(IGA_SA_record_plot);
            b=size(IGA_SA_record_p,2);
            if a<b
                IGA_SA_record_plot=[IGA_SA_record_plot IGA_SA_record_plot(end).*ones(1,b-a)];
            else
                IGA_SA_record_plot(b+1:a)=[];
            end
        end    
        IGA_SA_record_p(j,:) = IGA_SA_record_plot;             
    end
    IGA_SA_record_p_Ave = mean(IGA_SA_record_p,1);
    px = p_z*(1:size(IGA_SA_record_p_Ave,2)-1);
    px=[1 px];
    IGA_SAfigure{testNum,1} = px;
    IGA_SAfigure{testNum,2} = IGA_SA_record_p_Ave; 
% %     plot(px,PSO_record_p_Ave,'--','LineWidth',1.4);hold on;
    %eval(['save figure','\IGA_SA_case',num2str(testNum),' px',' IGA_SA_record_p_Ave']);    
    
    IGA_SA_time(testNum,1) = etime(clock,to)/run;
    IGA_SA_costBest(testNum,1) = min(IGA_SA_cost(testNum,:));
    IGA_SA_costAve(testNum,1) = mean(IGA_SA_cost(testNum,:));
    IGA_SA_costMid(testNum,1) = median(IGA_SA_cost(testNum,:));
    IGA_SA_costStd(testNum,1) = std(IGA_SA_cost(testNum,:));
    IGA_SA_tPerform(testNum,1) = mean(IGA_SA_Perform(testNum,:));
    fprintf('IGA_SA�㷨ƽ�����/mean result��%d\n',IGA_SA_costAve(testNum));
    fprintf('IGA_SA�㷨��λ�����/median result��%d\n',IGA_SA_costMid(testNum));
    fprintf('IGA_SA�㷨��׼����/standard deviation��%d\n',IGA_SA_costStd(testNum));
%     fprintf('������ɣ�%d\n',IGA_SA_tPerform(testNum,1));
    fprintf('IGA_SA����ʱ��/time(s):%d\n',IGA_SA_time(testNum));
    
    save dataIGA_SA IGA_SA_cost IGA_SA_costAve IGA_SA_costStd IGA_SA_time IGA_SAfigure;


% ----------------------------GA-------------------------%
    para=[2 2 0];%combination of initialization and constraint handling
%     para=[1 1 0; 1 2 0; 1 3 0; 1 4 0;
%         2 1 0; 2 2 0; 2 3 0; 2 4 0;
%         3 1 0; 3 2 0; 3 3 0; 3 4 0;
%         4 1 0; 4 2 0; 4 3 0; 4 4 0;];

    figure_data_temp_x = cell(size(para,1),1);
    figure_data_temp_y = cell(size(para,1),1);
    GA_cost_temp = zeros(run,size(para,1));
    for type=1:size(para,1)
        
        fprintf('----------------the %d-th GAHIR---------------\n',type);         
        GA_record_p = [];k=1;
        to = clock; 
        for r=1:run
            [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = GA_multi_mecha(Task,Agent,agentCost,Gmax,Np,p_z,para(type,1),para(type,2),para(type,3));
%             GA_gg_index(testNum,r,type) = g_index;
            GA_cost_temp(r,type) = gbestCost;
%             restaCount(testNum,r,type) = restartCount;%����������
%             GA_Perform(testNum,r,type) = taskPerform;%�Ƿ�����������
            if r>1
                a=length(record_plot);
                b=size(GA_record_p,2);
                if a<b
                    record_plot=[record_plot record_plot(end).*ones(1,b-a)];
                else
                    record_plot(b+1:a)=[];
                end
            end                
            GA_record_p(r,:) = record_plot;
        end
        GA_time_temp(1,type) = etime(clock,to)/run;
        %��ͼ
        GA_record_p_Ave = mean(GA_record_p,1);
        px = p_z*(1:size(GA_record_p_Ave,2)-1);
        px=[1 px];
        figure_data_temp_x{type,1}=px;%��ͼ����
        figure_data_temp_y{type,1}=GA_record_p_Ave;
        %eval(['save figure','\GA_case',num2str(testNum),'_type',num2str(type),' px',' GA_record_p_Ave']);

    end
    GA_cost(testNum,:,:) = GA_cost_temp;
    GA_figure_data{:,1,testNum} = figure_data_temp_x;
    GA_figure_data{:,2,testNum} = figure_data_temp_y;
    GA_time(testNum,:) = GA_time_temp;
    for type=1:size(para,1)
        GA_costBest(testNum,type) = min(GA_cost(testNum,:,type));
        GA_costAve(testNum,type) = mean(GA_cost(testNum,:,type));
        GA_costMid(testNum,type) = median(GA_cost(testNum,:,type));
        GA_costStd(testNum,type) = std(GA_cost(testNum,:,type));
%         GA_mPerform(testNum,type) = mean(GA_Perform(testNum,:,type));
    %     fprintf('��%d�����\n',k);
        fprintf('GA�㷨��ý��/best result��%d\n',GA_costBest(testNum,type));
        fprintf('GA�㷨ƽ�����/mean result��%d\n',GA_costAve(testNum,type));
        fprintf('GA�㷨��λ�����/median result��%d\n',GA_costMid(testNum,type));
        fprintf('GA�㷨��׼����/standard deviation��%d\n',GA_costStd(testNum,type));
%         fprintf('GA������ɣ�%d\n',GA_mPerform(testNum,type));
        fprintf('GA����ʱ��/time(s): %d\n',GA_time(testNum,type));
    end
        save dataGA_com GA_cost GA_costAve GA_costStd GA_time GA_figure_data;

end
toc;