function [gbestCost,genCost,taskPerform,record_plot] = IGA_SA(Task,Agent,agentCost,Gmax,NP,p_z)
% IGA-SA
agent_num = size(Agent,1);
ability_num = size(Task,2);
global cost_gen;
cost_gen=0;
re_plot=[];
gen = 1;t=1;
%% parameter settings
%parameter in GA
Np =100;
Pc = 0.8;
Pm = 0.2;
K=20;
%parameter in SA
SAGmax = 250��%200;
Tk = 2500��%sum(agentCost);% temperature
alpa = 0.9;
%Tk*(alpa^160)
restartCount = 0;record_plot=0;
%�����ʼ����
%random initialization
Pop = rand(Np,agent_num)>0.5;
%compute objective values
[PopCost,PopDone,re_plot] = IGASA_object_func(Pop,Task,Agent,agentCost,re_plot);

while cost_gen<=Gmax*(NP)
    for og = 1:2:Np
  %% -----------------------selection-------------% 
       s1 = GA_selection(Pop,PopCost,Np,K);
       s2 = GA_selection(Pop,PopCost,Np,K);
  %% -----------------one-point---crossover------------------%
       if rand<Pc
            s = GA_crossover(s1,s2,agent_num);
       else
           s = [s1;s2];
       end
  %% ---------------two-point----mutation--------------------%
        if rand<Pm
            r_temp = unidrnd(agent_num,2,2);
            s(1,r_temp(1,1)) = ~s(1,r_temp(1,1));
            s(1,r_temp(1,2)) = ~s(1,r_temp(1,2));
            s(2,r_temp(2,1)) = ~s(2,r_temp(2,1));
            s(2,r_temp(2,2)) = ~s(2,r_temp(2,2));
            Os(og:og+1,:) = s;
        else
            Os(og:og+1,:) = s;
        end
       
    end
    %compute objective values
    [OsCost,OsDone,re_plot] = IGASA_object_func(Os,Task,Agent,agentCost,re_plot);

    
    %-------------population update--------------%
    Pop = Os;
    PopCost = OsCost;
    PopDone = OsDone;
    %record,genCostÿ�����ţ�bestCostĿǰΪֹ����
    [genCost(gen),ls_index] = min(PopCost);
    genS(gen,:) = Pop(ls_index,:);
  %% %------------SA------------------%
    current_S = genS(gen,:);
    current_Cost = genCost(gen);
    current_Done = PopDone(ls_index,:);
    while Tk>0.0001
        for i=1:SAGmax
            %next_state
            if current_Done==1%feasilbe
                temp = find(current_S==1);
                cw = length(temp);
                cww = unidrnd(cw,1,1);
                next_S = current_S;
                next_S((temp(cww))) = ~next_S((temp(cww)));
            else%infeasible
                temp = find(current_S==0);
                cw = length(temp);
                cww = unidrnd(cw,1,1);
                next_S = current_S;
                next_S((temp(cww))) = ~next_S((temp(cww)));
            end
            
            [next_Cost,next_Done,re_plot] = IGASA_object_func(next_S,Task,Agent,agentCost,re_plot);
            delta = next_Cost-current_Cost;
            if delta<0
                current_S = next_S;
                current_Cost = next_Cost;
                current_Done = next_Done;
                if current_Cost<genCost(gen)%update state
                    genCost(gen) = current_Cost;
                    genS(gen,:) = current_S;
                end
            else
                acceptance_funtion = exp(-delta/Tk);
                if rand <acceptance_funtion
                    current_S = next_S;
                    current_Cost = next_Cost;
                    current_Done = next_Done;
                end
            end
        end
        Tk=Tk*alpa;%cooling
    end
    Pop(ls_index,:) = current_S;
    PopCost(ls_index,:) = current_Cost;
    PopDone(ls_index,:) = current_Done;
  %% ---------��¼ÿ�����/racord data---------------%  
        
    if gen==1
        bestCost(gen) = genCost(gen);
    else
        temp = bestCost(gen-1)<genCost(gen);
        bestCost(gen) = bestCost(gen-1).*temp + genCost(gen).*(~temp);
    end
    
    gen = gen+1;
end
%%
for i=1:p_z:length(re_plot)
    if i==1
        record_plot=re_plot(i);
    else
        c=min([record_plot re_plot(i-p_z:i)']);
        record_plot=[record_plot c];
    end
end
[gbestCost,g_index] = min(genCost);%best result in all iterations
gbestS = genS(g_index,:);
B_gbestS = gbestS*Agent;
temp1 = sum(B_gbestS>=Task,2);
taskPerform = (temp1==ability_num);

end

%------------------------selection-----------------------------%
function s = GA_selection(Pop,PopCost,Np,K)
    temp = unidrnd(Np,1,K);
    [~,index] = min(PopCost(temp));
    ind = temp(index);
    s = Pop(ind,:);   
end
%------------------------crossover-----------------------------%
function s = GA_crossover(s1,s2,agent_num)  
    r_temp = unidrnd(agent_num,1,1);
    s(1,:) = [s1(1:r_temp)  s2(r_temp+1:end)];
    s(2,:) = [s2(1:r_temp)  s1(r_temp+1:end)];        
end
function [Cost,taskDone,re_plot] = IGASA_object_func(coalition,Task,Agent,agentCost,re_plot)
%compute objective
global cost_gen;
ability_num = size(Task,2);
num = size(coalition,1);
cost_gen = cost_gen+num;
B = coalition*Agent;
temp = sum((B>=repmat(Task,num,1)),2);
taskDone = (temp==ability_num);
costSum = sum(agentCost);
costemp = coalition*agentCost;
cost_sub1 = taskDone.*costemp;
sub2_temp = ((repmat(Task,num,1)-B)>0).*(repmat(Task,num,1)-B);
cost_sub2 = (~taskDone).*costSum.*(1+sum(sub2_temp./repmat(Task,size(sub2_temp,1),1),2)/3);
Cost = cost_sub1 + cost_sub2;
re_plot = [re_plot; Cost];
end
