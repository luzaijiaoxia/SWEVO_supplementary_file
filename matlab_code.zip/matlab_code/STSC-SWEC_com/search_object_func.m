function [Cost,taskDone] = search_object_func(coalition,Task,Agent,agentCost)
%objective value
%0-1 encoding
global cost_gen;
ability_num = size(Task,2);
num = size(coalition,1);
cost_gen = cost_gen+num;
B = coalition*Agent;
temp = sum((B>=repmat(Task,num,1)),2);
taskDone = (temp==ability_num);
costSum = sum(agentCost);
costemp = coalition*agentCost;
cost_sub1 = taskDone.*costemp;

sub2_temp = ((repmat(Task,num,1)-B)>0).*(repmat(Task,num,1)-B);
cost_sub2 = (~taskDone).*costSum.*(1+sum(sub2_temp./repmat(Task,size(sub2_temp,1),1),2)/3);
Cost = cost_sub1 + cost_sub2;
end