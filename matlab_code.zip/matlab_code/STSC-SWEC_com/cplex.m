clc;clear
for testNum = 1:2
    run=20;
    fprintf('=================the %d-th instance=================\n',testNum);   
    for j=1:run
    eval(['load casefinal\case',num2str(testNum)]);

    agent_num = size(Agent,1);
    ability_num = size(Task,2);
    % Define variables
    x = binvar(1,agent_num);
    % Define constraints 
    xx = repmat(x',1,ability_num);
    absum = sum(Agent.*xx);
    Constraints = [absum>=Task];
    % Define an objective  
    Objective = sum(agentCost.*x');

    % Set some options for YALMIP and solver
    options = sdpsettings('solver','cplex');
    % Solve the problem
    sol = optimize(Constraints,Objective,options);
    ss_cplex_time(testNum,j) = sol.yalmiptime+sol.solvertime;
    % Analyze error flags
    if sol.problem == 0
        % Extract and display value
        solution = value(x);
        cost(testNum) = value(Objective);
    else
        display('Hmm, something went wrong!');
        sol.info
        yalmiperror(sol.problem)
    end
    
    
    feasible(testNum) =1;
    ss = repmat(solution',1,ability_num);
    check = sum(Agent.*ss);
    zz = sum(check>=Task);
    if zz~=ability_num
        feasible(testNum)=0;
    end
    
    cost_check(testNum) = sum(agentCost.*solution')==cost(testNum);
    end
    ss_cplex_timeAve = sum(ss_cplex_time,2)/run;
    save('STSC_Cplex', 'ss_cplex_timeAve', 'ss_cplex_time','cost','feasible','cost_check');
    fprintf('----------------cost:%d---------------\n',cost(testNum));
    fprintf('---------------------------------------------------------------------\n');
end

