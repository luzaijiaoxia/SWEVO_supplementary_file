function [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = GA_multi_mecha(Task,Agent,agentCost,Gmax,Np,p_z,initType,constraintDealType,LsType)
% GAHIR for the STSCF
agent_num = size(Agent,1);
ability_num = size(Task,2);
global cost_gen;
cost_gen=0;
gen = 1;t=1;
Pc = 0.9;
Pm = 0.001;
restartCount = 0;record_plot=0;
%��ʼ����Ⱥ
%initialize the population
switch initType
    case 1  %�����ʼ���� %%random initialization
        Pop = rand(Np,agent_num)>0.5;
    case 2  %һ����в�ȷ���Ĺ����ʼ���⣬�� %%incremental heuristic initialization
        [S] = dynaConstruct_uncertainS(Task,Agent,agentCost);
        Pop=S;
        Pop(size(S,1)+1:Np,:) = rand(Np-size(S,1),agent_num)>0.5;
    case 3  %ɾ %%decremental heuristic initialization
        [S] = dynaConstruct_delet(Task,Agent,agentCost);
        Pop=S;
        Pop(size(S,1)+1:Np,:) = rand(Np-size(S,1),agent_num)>0.5;
    case 4 %����һ���Ϻý�+��� %%hybrid generation based initialization 
        [Pop] = dynaConstructS(Task,Agent,agentCost);
        Pop(2:Np,:) = rand(Np-1,agent_num)>0.5;           
end
%Ŀ�꺯��ֵ����&���޸�
%repair solutions & compute objective values
switch constraintDealType       
    case 1  %������ %The penalty function method 
        [PopCost,PopDone] = search_object_func(Pop,Task,Agent,agentCost);
    case 2  %����޸� %%Random repair strategy
        [Pop,PopCost,PopDone] = search_solution_repair(Pop,Task,Agent,agentCost);
    case 3 %�������޸�+��� %%Hybrid repair strategy 
        [Pop,PopCost,PopDone] = search_solution_repair_rule_uncertain(Pop,Task,Agent,agentCost);
    case 4  %�������޸� %%Heuristic repair strategy
        [Pop,PopCost,PopDone] = search_solution_repair_rule(Pop,Task,Agent,agentCost);        
end
%GAHIR  iteration��ѭ��
while cost_gen<=Gmax*(Np)
    for og = 1:2:Np
  %-----------------------selection-------------% 
       s1 = GA_selection(Pop,PopCost,Np);
       s2 = GA_selection(Pop,PopCost,Np);
  %--------------------crossover------------------%
       if rand<Pc
            s = GA_crossover(s1,s2,agent_num);
       else
           s = [s1;s2];
       end
  %-------------------mutation--------------------%  
       randmtemp = rand(2,agent_num)<Pm;
       Os(og:og+1,:) = s.*(~randmtemp)+(~s).*randmtemp;

    end
    %Ŀ�꺯��ֵ����&���޸�
    switch constraintDealType       
        case 1  %������ %The penalty function method 
            [OsCost,OsDone] = search_object_func(Os,Task,Agent,agentCost);
        case 2  %����޸� %%Random repair strategy
            [Os,OsCost,OsDone] = search_solution_repair(Os,Task,Agent,agentCost);
        case 3 %�������޸�+��� %%Hybrid repair strategy 
            [Os,OsCost,OsDone] = search_solution_repair_rule_uncertain(Os,Task,Agent,agentCost);
        case 4  %�������޸� %%Heuristic repair strategy
            [Os,OsCost,OsDone] = search_solution_repair_rule(Os,Task,Agent,agentCost);      
    end
    
    %-------------population update--------------%
    %----------�����Ӵ�������--------%
    PopSum = [Pop;Os];
    PopSumCost = [PopCost;OsCost];
    PopSumDone = [PopDone;OsDone];
    [~,gen_index] = sort(PopSumCost);
    
    dindex=find(PopDone==1);
    PopCostMean = mean(PopCost(dindex));
    PopMax = max(PopCost(dindex));
    if isempty(dindex)
        upk(gen)=1;
    else
        upk(gen)=(PopMax-PopCostMean)/PopMax;
    end
    SubNp(gen) = round(Np/2)+round(upk(gen)*Np);
    SubNp(gen)=Np;%(SubNp(gen)>Np)*Np+~(SubNp(gen)>Np)*SubNp(gen);
    
    PopCostStd = std(PopCost(dindex),1);
    
    Pop = PopSum(gen_index(1:SubNp(gen)),:);
    PopCost = PopSumCost(gen_index(1:SubNp(gen)),:);
    PopDone = PopSumDone(gen_index(1:SubNp(gen)),:);
    
    upindex = SubNp(gen)+randperm(size(PopSumCost,1)-SubNp(gen),Np-SubNp(gen));%���
    Pop(SubNp(gen)+1:Np,:) = PopSum(upindex,:);
    PopCost(SubNp(gen)+1:Np,:) = PopSumCost(upindex,:);
    PopDone(SubNp(gen)+1:Np,:) = PopSumDone(upindex,:);

    %---------��¼ÿ�����---------------%  
    %record data
    %%record,genCost is the best in each generation
    %%bestCost is the best up to now.
    [genCost(gen),ls_index] = min(PopCost);
    genS(gen,:) = Pop(ls_index,:);    
    if gen==1
        bestCost(gen) = genCost(gen);
    else
        temp = bestCost(gen-1)<genCost(gen);
        bestCost(gen) = bestCost(gen-1).*temp + genCost(gen).*(~temp);
    end
    
    %plot data
    genflag = floor(cost_gen/(p_z));
    if genflag==1&&t==1
        record_plot(t:genflag) = bestCost(gen);
        t=t+1;
    elseif genflag>=t
        record_plot(t:genflag) = bestCost(gen);
        t = genflag+1;%t+1;    
    end 
    
    %---------------������ /restart---------------%
   
    if PopCostStd<1
            restartCount = restartCount +1;
            %��ʼ����Ⱥ
            %initialize the population
            switch initType
                case 1  %�����ʼ���� %%random initialization
                    Pop = rand(Np,agent_num)>0.5;
                case 2  %һ����в�ȷ���Ĺ����ʼ���⣬�� %%incremental heuristic initialization
                    [S] = dynaConstruct_uncertainS(Task,Agent,agentCost);
                    Pop=S;
                    Pop(size(S,1)+1:Np,:) = rand(Np-size(S,1),agent_num)>0.5;
                case 3  %ɾ %%decremental heuristic initialization
                    [S] = dynaConstruct_delet(Task,Agent,agentCost);
                    Pop=S;
                    Pop(size(S,1)+1:Np,:) = rand(Np-size(S,1),agent_num)>0.5;
                case 4 %����һ���Ϻý�+��� %%hybrid generation based initialization 
                    [Pop] = dynaConstructS(Task,Agent,agentCost);
                    Pop(2:Np,:) = rand(Np-1,agent_num)>0.5;           
            end
            %Ŀ�꺯��ֵ����&���޸�
            %repair solutions & compute objective values
            switch constraintDealType       
                case 1  %������ %The penalty function method 
                    [PopCost,PopDone] = search_object_func(Pop,Task,Agent,agentCost);
                case 2  %����޸� %%Random repair strategy
                    [Pop,PopCost,PopDone] = search_solution_repair(Pop,Task,Agent,agentCost);
                case 3 %�������޸�+��� %%Hybrid repair strategy 
                    [Pop,PopCost,PopDone] = search_solution_repair_rule_uncertain(Pop,Task,Agent,agentCost);
                case 4  %�������޸� %%Heuristic repair strategy
                    [Pop,PopCost,PopDone] = search_solution_repair_rule(Pop,Task,Agent,agentCost);        
            end
    end
    
    gen = gen+1;
end

record_plot = [bestCost(1) record_plot];

[gbestCost,g_index] = min(genCost);%�����������Ž��
gbestS = genS(g_index,:);
B_gbestS = gbestS*Agent;%�жϽ���Ƿ��ִ������
temp1 = sum(B_gbestS>=Task,2);
taskPerform = (temp1==ability_num);

end

%------------------------selection-----------------------------%
function s = GA_selection(Pop,PopCost,Np)
    temp = randperm(Np,2);
    [~,index] = min(PopCost(temp));
    ind = temp(index);
    s = Pop(ind,:);   
end
%------------------------crossover-----------------------------%
function s = GA_crossover(s1,s2,agent_num)  
    r = rand(1,agent_num);
    r_temp = r>0.5;
    s(1,:) = s1.*r_temp + s2.*~(r_temp);
    s(2,:) = s2.*r_temp + s1.*~(r_temp);        
end
%------------------------mutation-----------------------------%
function s = GA_mutation(s,agent_num)
    temp = randi(agent_num,1,2);
    s(1,temp(1)) = ~(s(1,temp(1))); 
    s(2,temp(2)) = ~(s(2,temp(2))); 
end
