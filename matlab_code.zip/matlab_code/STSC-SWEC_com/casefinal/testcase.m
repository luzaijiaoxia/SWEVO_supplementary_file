function testcase
%test case generator
clear;

ability_num = 3;
N = [20 30 40 50  100 150 200 250 350 400 450 500];
c = 1;
for i = 1:12
Agent = randi(200,N(i),3);
for j=1:ability_num
    temp = sum(Agent(:,j));
    Task(j) = randi(temp,1,1);
end
agentCost = randi(200,N(i),1);
eval(['save case',num2str(c),' Task',' Agent',' agentCost']);
c = c+1;
end

