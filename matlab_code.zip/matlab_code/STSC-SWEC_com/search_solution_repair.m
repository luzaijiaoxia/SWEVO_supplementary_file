function [Pop,PopCost,taskDone] = search_solution_repair(Pop,Task,Agent,agentCost)
%Random repair strategy
global cost_gen;
num = size(Pop,1);
cost_gen = cost_gen+num;
ability_num = size(Task,2);
B = Pop*Agent;
temp = sum((B>=repmat(Task,num,1)),2);
taskDone = (temp==ability_num);
index_Pop = find(taskDone==0);
index_size = length(index_Pop);
for i = 1:index_size
    fPop = find(Pop(index_Pop(i),:)==0);
    while 1
        temp = randi(length(fPop));
        Pop(index_Pop(i),fPop(temp)) = 1;
        fPop(temp)=[];
        
        B = Pop(index_Pop(i),:)*Agent;
        temp = sum((B>=Task),2);
        taskDone(index_Pop(i)) = (temp==ability_num);
        if taskDone(index_Pop(i))==1
            break;
        end
    end
end

PopCost = Pop*agentCost;
end