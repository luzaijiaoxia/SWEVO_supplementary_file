function [S] = dynaConstructS(Task,Agent,agentCost)
%%hybrid generation based initialization 
agent_num = size(Agent,1);
ability_num = size(Task,2);
task = Task;
agent = Agent;
agentcost = agentCost;
agent_order = 1:agent_num;
g = 1;
done = 0;
S = zeros(1,agent_num);
while done==0
    t_a = task./sum(agent);
    t_a_ratio = t_a./sum(t_a);
    t_a_temp = repmat(t_a_ratio,size(agent,1),1).*agent;
    t_a_z = sum(t_a_temp,2)./agentcost;
    
    [~,A_r_index] = max(t_a_z); 
    S_temp(g) = agent_order(A_r_index);
    task = task -agent(A_r_index,:);
    task = (task>=0).*task;
    agent_order(A_r_index) = [];
    agent(A_r_index,:) = [];
    agentcost(A_r_index)=[];

    if sum(task<=0,2)==ability_num
        done=1;
    end
   g=g+1; 
end

S(S_temp) = 1;

end