function [gbestCost,genCost,taskPerform,record_plot] = BMBO(Task,Agent,agentCost,Gmax,NP,p_z)
%BMBO algorithm
global cost_gen;
cost_gen=1;t =1;
agent_num = size(Agent,1);%agent number
ability_num = size(Task,2);%type number of ability
task_num = size(Task,1);%task ability
%% initial parameter setting
Np=round(1.5*NP);%popsize
partition=5/12; % the percentage of population for MBO
peri = 1.2;%migration period
mig_p = 5/12;%migration ratio 

Smax =1.0;%max step
BAR = 5/12;%butterfly adjusting rate
Maxgen =50;

RG =50;%the generation interval between recombination is set to 5.
Np1 = ceil(mig_p*Np);%subpopulation1
Np2 = Np-Np1;

Keep = 2; % elitism parameter: how many of the best habitats to keep from one generation to the next
%% initial Population
Pop_x = -10+20*rand(Np,agent_num);%ʵֵ/real
Pop_y = (1./(1+exp(-Pop_x)))>0.5;%����0-1,ӳ��/0-1
[PopCost,~] = search_object_func(Pop_y,Task,Agent,agentCost);

[Cost,indices]  =sort(PopCost,'ascend');%,�����ɺõ��Np1�Ǹ��õ�/sort
Pop_x = Pop_x(indices,:);
Pop_y = Pop_y(indices,:);
PopCost =Cost;

%%
gen = 1;t=1;
record_plot=0;
while cost_gen<=Gmax*(NP)
    %% Save the best monarch butterflis in a temporary array.
    for j =1:Keep
        popxKeep(j,:) = Pop_x(j,:);
        popyKeep(j,:) = Pop_y(j,:);
        costKeep(j,1) = PopCost(j);
    end
    %% Divide the whole population into Population1 (Land1) and Population2 (Land2)
    if gen==1||mod((gen-1),RG)==0
        SubPop1 = Pop_x(1:Np1,:);%better
        SubPop2 = Pop_x(Np1+1:Np,:);
    end
    %%
    Land1_x = zeros(Np1,agent_num);
    Land2_x = zeros(Np2,agent_num);
    %% Migration operator on Subpopulation1,parameter peri&mig_p
    for i=1:Np1
       for j=1:agent_num
          r = rand*peri;
          if r<=mig_p
              r1 = randi(Np1);
              Land1_x(i,j) = SubPop1(r1,j);
          else             
              r2 = randi(Np2);
              Land1_x(i,j) = SubPop2(r2,j);
          end
       end
        
    end
    % Evaluate
    Land1_y =  (1./(1+exp(-Land1_x)))>0.5;%����0-1,ӳ��
    [Land1Cost,~] = search_object_func(Land1_y,Task,Agent,agentCost);
    
    
    %% Adjust  operator
    for i=1:Np2
        scale = Smax/(gen^2); 
        StepSzie = ceil(exprnd(2*Maxgen,1,1));
        dX = LevyFlight(StepSzie,agent_num);
        for j=1:agent_num
            if rand<=mig_p
                Land2_x(i,j) = Pop_x(1,j);%Elitism & sort=>Pop(1)=best
            else
                r3 = randi(Np2);
                Land2_x(i,j) = SubPop2(r3,j);
                if rand>BAR 
                    Land2_x(i,j) = Land2_x(i,j)+scale*(dX(j)-0.5);
                end
            end
        end
    end
    Land2_y =  (1./(1+exp(-Land2_x)))>0.5;%����0-1,ӳ��
    [Land2Cost,~] = search_object_func(Land2_y,Task,Agent,agentCost);
    %% repair GOA on Land1&2
    [Ybest(1,:),YbestCost(1,1)] = repair_GOA(Land1_y,Task,Agent,agentCost);
    [Ybest(2,:),YbestCost(2,1)] = repair_GOA(Land2_y,Task,Agent,agentCost);
    %%
    SubPop1 = Land1_x;
    SubPop2 = Land2_x;
    
    %% Combine Population1 with Population2 to generate a new Population
    Pop_x = [Land1_x;Land2_x];
    Pop_y = [Land1_y;Land2_y];
    PopCost = [Land1Cost;Land2Cost];
    [Cost,indices]  =sort(PopCost,'ascend');%,�����ɺõ��Np1�Ǹ��õ�
    Pop_x = Pop_x(indices,:);
    Pop_y = Pop_y(indices,:);
    PopCost =Cost;
    
    %% Elitism strategy
    for i=1:Keep
       Pop_x(Np-i+1,:) = popxKeep(i,:);
       Pop_y(Np-i+1,:) = popyKeep(i,:);
       PopCost(Np-i+1) =costKeep(i);
    end
    [Cost,indices]  =sort(PopCost,'ascend');%,�����ɺõ��Np1�Ǹ��õ�
    Pop_x = Pop_x(indices,:);
    Pop_y = Pop_y(indices,:);
    PopCost =Cost;
   
    
    %% ---------��¼ÿ�����/record data---------------%  
    %%record,genCostÿ�����ţ�bestCostĿǰΪֹ����
    %%record,genCost is the best in each generation
    %%bestCost is the best up to now.
    PopTe = [PopCost;YbestCost];
    YTe = [Pop_y;Ybest];
    [genCost(gen),ls_index] = min(PopTe);
%     genS_x(gen,:) = Pop_x(ls_index,:); 
    genS_y(gen,:) = YTe(ls_index,:);    
    if gen==1
        bestCost(gen) = genCost(gen);
    else
        temp = bestCost(gen-1)<genCost(gen);
        bestCost(gen) = bestCost(gen-1).*temp + genCost(gen).*(~temp);
    end
    
    %plot����¼��ͬ���۴���ʱ��ֵ
    genflag = floor(cost_gen/(p_z));
    if genflag==1&&t==1
        record_plot(t:genflag) = bestCost(gen);
        t=t+1;
    elseif genflag>=t
        record_plot(t:genflag) = bestCost(gen);
        t = genflag+1;%t+1;    
    end
    gen = gen+1;
end


[gbestCost,g_index] = min(genCost);%�����������Ž��/best result
gbestS = genS_y(g_index,:);
B_gbestS = gbestS*Agent;%�жϽ���Ƿ��ִ������
temp1 = sum(B_gbestS>=Task,2);
taskPerform = (temp1==ability_num);

end

function [delataX] = LevyFlight(StepSize, Dim)
%Allocate matrix for solutions
delataX = zeros(1,Dim);
%Loop over each dimension
for i=1:Dim
    % Cauchy distribution
    fx = tan(pi * rand(1,StepSize));
    delataX(i) = sum(fx);
end
end

function [Ybest,YbestCost] = repair_GOA(Land_y,Task,Agent,agentCost)
agent_num = size(Agent,1);
B_Ave = sum(Agent,2)./size(Agent,2);
rat = B_Ave./agentCost;
[~,H] = sort(rat,'descend');%H��Խ��Խ��ǰԽ���ȼ�������
for i=1:size(Land_y,1)
    weight = Land_y(i,:)*Agent;
    temp = weight>Task;
    temp  = sum(temp)==length(Task);
    % repair
    if temp==0
        for j=1:agent_num
            if Land_y(i,H(j))==0
                Land_y(i,H(j)) = 1;
                weight =weight+Agent(H(j),:);
                temp = weight>=Task;
                temp  = sum(temp)==length(Task);
                if temp==1
                    break;
                end                 
            end
        end 
    end
    %optimize,��H��С��������
    for j=agent_num:-1:1
        if Land_y(i,H(j)) == 1            
            tempw = weight-Agent(H(j),:);
            temp = tempw>=Task;
            temp  = sum(temp)==length(Task);
            if temp==1
                Land_y(i,H(j)) =0;
                weight = weight-Agent(H(j),:);
            end
        end
    end
    
end
[LandCost,~] = search_object_func(Land_y,Task,Agent,agentCost);
[~,indices]  =sort(LandCost,'ascend');%,�����ɺõ���
Ybest = Land_y(indices(1),:);
YbestCost = LandCost(indices(1),:);

end