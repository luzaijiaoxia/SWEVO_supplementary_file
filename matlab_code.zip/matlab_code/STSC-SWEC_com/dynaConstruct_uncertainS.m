function [S] = dynaConstruct_uncertainS(Task,Agent,agentCost)
%%incremental heuristic initialization
agent_num = size(Agent,1);
ability_num = size(Task,2);
agentcost = agentCost;
S = zeros(agent_num,agent_num);
for i=1:agent_num
    task = Task;
    agent = sum(Agent);
    done = 0;
    agent_order = 1:agent_num;
while done==0
    if rand<0.3
        A_r_index=agent_order(randi(length(agent_order),1));
    else
        t_a = task./agent;
        t_a_ratio = t_a./sum(t_a,2);
        t_a_temp = repmat(t_a_ratio,agent_num,1).*Agent;
        t_a_z = sum(t_a_temp,2)./agentcost;
        t_a_z = (~(S(i,:)')).*t_a_z;
        [~,A_r_index] = max(t_a_z); 
    end
    S(i,A_r_index)=1;
    agent = agent-Agent(A_r_index,:);
    task = task -Agent(A_r_index,:);
    task = (task>=0).*task;
    zz = find(agent_order==A_r_index,1);
    agent_order(zz)=[];
    if sum(task<=0,2)==ability_num
        done=1;
    end
end
end

end