function [gbestCost,gbestS,restartCount,taskPerform,record_plot,g_index] = stochastic_search(Task,Agent,agentCost,Gmax,Np,p_z)
% ���������ⵥ������������
% RS
agent_num = size(Agent,1);
ability_num = size(Task,2);
global cost_gen;
cost_gen=0;
gen = 1;t=1;
%��ʼ����Ⱥ
%random initialization
restartCount = 0;record_plot=0;
while cost_gen<=Gmax*(Np)
    Pop = zeros(Np,agent_num);
    for i=1:Np
        ar = randperm(agent_num);
        ar_agent = Agent(ar,:);
        agent_cum = cumsum(ar_agent);
        agent_cum_temp = agent_cum>repmat(Task,agent_num,1);
        s_index = find((sum(agent_cum_temp,2)==ability_num)==1,1);
        
        Pop(i,ar(1:s_index)) = 1;
    end
    
    [PopCost,~] = search_object_func(Pop,Task,Agent,agentCost);
    %---------��¼ÿ�����/record data---------------%  
    %record,genCostÿ�����ţ�bestCostĿǰΪֹ����
    %%record,genCost is the best in each generation
    %%bestCost is the best up to now.
    [genCost(gen),ls_index] = min(PopCost);
    genS(gen,:) = Pop(ls_index,:);    
    if gen==1
        bestCost(gen) = genCost(gen);
    else
        temp = bestCost(gen-1)<genCost(gen);
        bestCost(gen) = bestCost(gen-1).*temp + genCost(gen).*(~temp);
    end
    
    %plot����¼��ͬ���۴���ʱ��ֵ
    genflag = floor(cost_gen/(p_z));
    if genflag==1&&t==1
        record_plot(t:genflag) = bestCost(gen);
        t=t+1;
    elseif genflag>=t
        record_plot(t:genflag) = bestCost(gen);
        t = genflag+1;
    end 
    
    gen = gen+1;
end

record_plot = [bestCost(1) record_plot];

[gbestCost,g_index] = min(genCost);
gbestS = genS(g_index,:);
B_gbestS = gbestS*Agent;
temp1 = sum(B_gbestS>=Task,2);
taskPerform = (temp1==ability_num);

end
