function [Pop,PopCost,taskDone] = search_solution_repair_rule_uncertain(Pop,Task,Agent,agentCost)
%%Hybrid repair strategy 
global cost_gen;
num = size(Pop,1);
agent_num = size(Agent,1);
cost_gen = cost_gen+num;
ability_num = size(Task,2);
B = Pop*Agent;
temp = sum((B>=repmat(Task,num,1)),2);
taskDone = (temp==ability_num);
index_Pop = find(taskDone==0);
index_size = length(index_Pop);
for i = 1:index_size
    fPop = find(Pop(index_Pop(i),:)==0);
    agent = Agent(fPop,:);
    agentcost = agentCost(fPop,:);
    task = Task-B(index_Pop(i),:);task = (task>=0).*task;
    t_a = task./sum(agent,1);
    t_a_ratio = t_a./sum(t_a,2);
    t_a_temp = repmat(t_a_ratio,size(agent,1),1).*agent;
    t_a_z = sum(t_a_temp,2)./agentcost;
    while 1 
        if rand <0.3
            sl = randi(length(t_a_z),1);
        else
            [~,sl] = max(t_a_z); 
        end
        
        Pop(index_Pop(i),fPop(sl)) = 1;
        
        B(index_Pop(i),:)=B(index_Pop(i),:)+Agent(fPop(sl),:);
        temp = sum((B(index_Pop(i),:)>=Task),2);
        taskDone(index_Pop(i)) = (temp==ability_num);
        if taskDone(index_Pop(i))==1
            break;
        end
        fPop(sl)=[];t_a_z(sl)=[];
    end
end

PopCost = Pop*agentCost;
end